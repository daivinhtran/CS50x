<div>
    Name: <?= htmlspecialchars($name) ?>
</div>
<div>
    Symbol: <?= htmlspecialchars($symbol) ?>
</div>
<div>
    Price: <?= htmlspecialchars($price) ?>
</div>