<form action="deposit.php" method="post">
    <fieldset>
        <div class="form-group">
            <input class="form-control" name="cash" placeholder="Cash" type="number"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Deposit</button>
        </div>
    </fieldset>
</form>
<div>
    or <a href="index.php">Portfolio</a>
</div>


